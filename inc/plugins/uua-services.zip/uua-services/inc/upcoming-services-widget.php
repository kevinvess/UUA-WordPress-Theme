<?php
	/**
		*
		* Create Upcoming Services Widget for UUA Theme
		*
		*/


add_action( 'widgets_init', 'uu_upcomingservice_init' );

function uu_upcomingservice_init() {
	register_widget( 'upcoming_service_list_widget' );
}

class upcoming_service_list_widget extends WP_Widget
{

  public function __construct()
    {
        $widget_ops = array(
            'classname' => 'upcoming_service_list_widget',
            'description' => 'Creates a sidebar widget for the next upcoming service'
        );

        parent::__construct( 'upcoming_service_list_widget', 'UUA Upcoming Service List Widget', $widget_ops );
    }


  public function widget( $args, $instance )
  {
		echo $args['before_widget'];
		?>
		
    <?php // Create and run custom loop
	    $us_list_args = array( 
	     'post_type' 			=> 'uu_services',
	     'post_status' 		=> 'future',
	     'order'					=> 'ASC',
	     'posts_per_page'	=> 1
	    );
      $upcoming_service_list = new WP_Query( $us_list_args );
      if ( $upcoming_service_list->have_posts() ) : 
    ?>

		<?php if (!empty($instance['title'])) { ?>
			<h3><?php echo esc_html( $instance['title'] ) ?></h3>			
		<?php } ?>
		
		<ul>
    <?php while ($upcoming_service_list->have_posts()) : $upcoming_service_list->the_post(); ?>
      <li>
      	<header><?php the_title(); ?></header>
      	<p class="small"><span class="speaker"><?php 
      	global $post;
	    	$terms = wp_get_post_terms($post->ID, 'uu_service_speaker');
				$count = count($terms);
				if ( $count > 0 ) {
				    foreach ( $terms as $term ) {
				        echo $term->name;
				    }
				}
			?></span> <time class="" datetime="<?php echo get_the_time('c'); ?>"><?php the_time('F j | g:i a'); ?></time></p>
      <?php the_excerpt(); ?>
      </li>
    <?php endwhile; endif; ?>
    <?php wp_reset_postdata(); ?>
		</ul>
	
		<?php
		echo $args['after_widget'];
  }

	public function update( $new_instance, $old_instance ) {  
	    return $new_instance;
	}

    public function form( $instance )
    {

			$title = '';
	    if( !empty( $instance['title'] ) ) {
	        $title = $instance['title'];
	    }
      ?>
        <p>
          <label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
          <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
    <?php
    }
}