<?php
/*
 * Creation of Service Post Type and Taxonomies
 */


// Create Service Custom Post Type
add_action('init', 'uu_services_cpt_init');
function uu_services_cpt_init() {
  
  $labels = array(
    'name' 								=> __( 'Services', 'uu-services' ),
    'singular_name' 			=> __( 'Service', 'uu-services' ),
    'add_new' 						=> __( 'Add New', 'uu-services' ),
    'add_new_item' 				=> __( 'Add New Service', 'uu-services' ),
    'edit_item' 					=> __( 'Edit Service', 'uu-services' ),
    'new_item' 						=> __( 'New Service', 'uu-services' ),
    'view_item' 					=> __( 'View Service', 'uu-services' ),
    'search_items' 				=> __( 'Search Services', 'uu-services' ),
    'not_found' 					=> __( 'No services found', 'uu-services' ),
    'not_found_in_trash' 	=> __( 'No services found in Trash', 'uu-services' ),
    'menu_name' 					=> __( 'Services', 'uu-services' ),
  );

  $args = array(
    'labels' 							=> $labels,
    'public' 							=> true,
    'publicly_queryable' 	=> true,
    'show_ui' 						=> true,
    'show_in_nav_menus'		=> false,
    'show_in_menu' 				=> true,
    'show_in_admin_bar'		=> true,
    'menu_position'				=> 5,
    'query_var' 					=> true,
		'capability_type' 		=> 'post',
    'has_archive' 				=> true,
    'rewrite' 						=> array( 'slug' => 'services', 'with_front' => false, 'feeds' => true,  ),
    'hierarchical' 				=> false,
    'taxonomies'					=> array( 'uu_service_speakers', 'uu_service_topics' ),
    'supports' 						=> array( 'title', 'editor', 'author', 'excerpt', 'comments', 'thumbnail', 'revisions', 'custom-fields' )
  ); 
  register_post_type('uu_services',$args);
}

//create new taxonomies: speakers & topics
add_action( 'init', 'create_uu_services_taxonomies', 0 );
function create_uu_services_taxonomies() {

//Speakers
$labels = array(	
	'name' 												=> __( 'Speakers', 'uu-services' ),
	'singular_name' 							=> __( 'Speaker', 'uu-services' ),
	'menu_name' 									=> __( 'Speakers', 'uu-services' ),
	'search_items' 								=> __( 'Search speakers', 'uu-services' ),
	'popular_items' 							=> __( 'Most frequent speakers', 'uu-services' ),
	'all_items' 									=> __( 'All speakers', 'uu-services' ),
	'edit_item' 									=> __( 'Edit speakers', 'uu-services' ),
	'update_item' 								=> __( 'Update speakers', 'uu-services' ),
	'add_new_item' 								=> __( 'Add new speaker', 'uu-services' ),
	'new_item_name' 							=> __( 'New speaker name', 'uu-services' ),
	'separate_items_with_commas' 	=> __( 'Separate multiple speakers with commas', 'uu-services' ),
	'add_or_remove_items' 				=> __( 'Add or remove speakers', 'uu-services' ),
	'choose_from_most_used' 			=> __( 'Choose from most frequent speakers', 'uu-services' ),
	'parent_item' 								=> null,
  'parent_item_colon' 					=> null,
);

register_taxonomy('uu_service_speaker','uu_services', array(
	'hierarchical' 			=> false,
	'labels' 						=> $labels,
	'show_ui' 					=> true,
	'show_admin_column' => true,
	'query_var' 				=> true,
  'rewrite' 					=> array( 'slug' => 'speaker' )
));

//Service Topics
$labels = array(	
	'name' 												=> __( 'Service topics', 'uu-services' ),
	'singular_name' 							=> __( 'Service topic', 'uu-services' ),
	'menu_name' 									=> __( 'Service topics', 'uu-services' ),
	'search_items' 								=> __( 'Search service topics', 'uu-services' ),
	'popular_items' 							=> __( 'Most popular service topics', 'uu-services' ),
	'all_items' 									=> __( 'All service topics', 'uu-services' ),
	'edit_item' 									=> __( 'Edit service topic', 'uu-services' ),
	'update_item' 								=> __( 'Update service topic', 'uu-services' ),
	'add_new_item' 								=> __( 'Add new service topic', 'uu-services' ),
	'new_item_name' 							=> __( 'New service topic', 'uu-services' ),
	'separate_items_with_commas' 	=> __( 'Separate service topics with commas', 'uu-services' ),
	'add_or_remove_items' 				=> __( 'Add or remove service topics', 'uu-services' ),
	'choose_from_most_used' 			=> __( 'Choose from most used service topics', 'uu-services' ),
	'parent_item' 								=> null,
    'parent_item_colon' 				=> null,
);

register_taxonomy('uu_service_topics','uu_services', array(
	'hierarchical' 			=> true,
	'labels' 						=> $labels,
	'show_ui' 					=> true,
	'show_admin_column' => true,
	'query_var' 				=> true,
  'rewrite' 					=> array( 'slug' => 'topic' )
));

}

// Custom taxonomy terms dropdown function
function uuservices_get_term_dropdown($taxonomy) {
	$terms = get_terms($taxonomy);
	foreach ($terms as $term) {
		$term_slug = $term->slug;
		$current_speaker = get_query_var('uu_service_speaker');
		$current_topic = get_query_var('uu_service_topics');
		if($term_slug == $current_speaker || $term_slug == $current_topic ) {
			echo '<option value="'.$term->slug.'" selected>'.$term->name.'</option>';
		} else {
			echo '<option value="'.$term->slug.'">'.$term->name.'</option>';
		}
	}
}


function uu_services_rewrite_flush() {
    // First, we "add" the custom post type via the above written function.
    // Note: "add" is written with quotes, as CPTs don't get added to the DB,
    // They are only referenced in the post_type column with a post entry, 
    // when you add a post of this CPT.
    uu_services_cpt_init();

    // ATTENTION: This is *only* done during plugin activation hook in this example!
    // You should *NEVER EVER* do this on every page load!!
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'uu_services_rewrite_flush' );