<?php 
	
	function uuaservices_shortcode_upcoming_services( $atts ){ 
	
	  $usshortcode_args = array( 
	     'post_type' 			=> 'uu_services',
	     'post_status' 		=> 'future',
	     'order'					=> 'ASC',
	     'posts_per_page'	=> -1
	    );
      $upcoming_service_shortcode = new WP_Query( $usshortcode_args );
      if ( $upcoming_service_shortcode->have_posts() ) : ?>
			
      <div class="uu-service-list">
				<?php while ($upcoming_service_shortcode->have_posts()) : $upcoming_service_shortcode->the_post(); ?>
	      
		      <article <?php post_class('featured'); ?>>
			      <p class="small service-meta"><time datetime="<?php echo get_the_time('c'); ?>"><?php the_time('M j, Y'); ?></time> <span class="speaker"><?php the_terms( '', 'uu_service_speaker', '', ', ' ); ?></span> <span class="speaker"><?php the_terms( '', 'uu_service_topics', '', ', ' ); ?></span></p>
			      <div class="entry-content">
				      <h3><?php the_title(); ?></h3>
				      <?php the_excerpt(); ?>
			      </div>
		      </article>
		      
					<?php endwhile; ?>
	      </div>
	    <?php endif; ?>
    <?php wp_reset_postdata(); 

  }

add_shortcode( 'upcoming-services', 'uuaservices_shortcode_upcoming_services' );