<?php
	/**
		*
		* Create Upcoming Services Widget for UUA Theme
		*
		*/


add_action( 'widgets_init', 'uuservice_init' );

function uuservice_init() {
	register_widget( 'upcomingservice_widget' );
}

class upcomingservice_widget extends WP_Widget
{

  public function __construct()
    {
        $widget_ops = array(
            'classname' => 'upcomingservice_widget',
            'description' => 'Creates a widget box for the featured upcoming service.'
        );

        parent::__construct( 'upcomingservice_widget', 'UUA Featured Upcoming Service Widget', $widget_ops );
    }


  public function widget( $args, $instance )
  {
		echo $args['before_widget'];
		?>
		
    <?php // Create and run custom loop
	    $us_args = array( 
	     'post_type' 			=> 'uu_services',
	     'post_status' 		=> 'future',
	     'order'					=> 'ASC',
	     'posts_per_page'	=> 1
	    );
      $upcoming_service = new WP_Query( $us_args );
      if ( $upcoming_service->have_posts() ) : 
    ?>
    <small><?php echo esc_html( $instance['title'] ) ?></small>

    <?php while ($upcoming_service->have_posts()) : $upcoming_service->the_post(); ?>
      <h3><?php the_title(); ?></h3>
    	<p class="small"><span class="speaker"><?php 
      	global $post;
	    	$terms = wp_get_post_terms($post->ID, 'uu_service_speaker');
				$count = count($terms);
				if ( $count > 0 ) {
				    foreach ( $terms as $term ) {
				        echo $term->name;
				    }
				}
			?></span> <time class="" datetime="<?php echo get_the_time('c'); ?>"><?php the_time('F j - g:i a'); ?></time></p>
      <?php the_excerpt(); ?>
    <?php endwhile; endif; ?>
    <?php wp_reset_postdata(); ?>
    <ul>
		<?php if (!empty($instance['firsttimevisitorlink'])) { ?>
			<li><a href="<?php echo $instance['firsttimevisitorlink'] ?>"><i class="fa fa-star"></i> <br />First Time Visitor?</a></li>			
		<?php } ?>
		<?php if (!empty($instance['upcomingserviceslink'])) { ?>
			<li><a href="<?php echo $instance['upcomingserviceslink'] ?>"><i class="fa fa-calendar-plus-o"></i> <br />Upcoming Services</a></li>			
		<?php } ?>
		<?php if (!empty($instance['servicearchivelink'])) { ?>
			<li><a href="<?php echo $instance['servicearchivelink'] ?>"><i class="fa fa-list"></i> <br />Service Archive</a></li>			
		<?php } ?>
		</ul>
	
		<?php
		echo $args['after_widget'];
  }

	public function update( $new_instance, $old_instance ) {  
	    return $new_instance;
	}

    public function form( $instance )
    {

			$title = '';
	    if( !empty( $instance['title'] ) ) {
	        $title = $instance['title'];
	    }

	    $upcomingserviceslink = '';
	    if( !empty( $instance['upcomingserviceslink'] ) ) {
	        $upcomingserviceslink = $instance['upcomingserviceslink'];
	    }

	    $servicearchivelink = '';
	    if( !empty( $instance['servicearchivelink'] ) ) {
	        $servicearchivelink = $instance['servicearchivelink'];
	    }

	    $firsttimevisitorlink = '';
	    if( !empty( $instance['firsttimevisitorlink'] ) ) {
	        $firsttimevisitorlink = $instance['firsttimevisitorlink'];
	    }
	    	    
      ?>
        <p>
          <label for="<?php echo $this->get_field_name( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
          <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        
        <p>
          <label for="<?php echo $this->get_field_name( 'upcomingserviceslink' ); ?>"><?php _e( 'Link to Upcoming Services:' ); ?></label>
          <input class="widefat" id="<?php echo $this->get_field_id( 'upcomingserviceslink' ); ?>" name="<?php echo $this->get_field_name( 'upcomingserviceslink' ); ?>" type="text" value="<?php echo esc_attr( $upcomingserviceslink ); ?>" />
        </p>
        
        <p>
          <label for="<?php echo $this->get_field_name( 'servicearchivelink' ); ?>"><?php _e( 'Link to Service Archive:' ); ?></label>
          <input class="widefat" id="<?php echo $this->get_field_id( 'servicearchivelink' ); ?>" name="<?php echo $this->get_field_name( 'servicearchivelink' ); ?>" type="text" value="<?php echo esc_attr( $servicearchivelink ); ?>" />
        </p>

        <p>
          <label for="<?php echo $this->get_field_name( 'firsttimevisitorlink' ); ?>"><?php _e( 'Link to First Time Visitor:' ); ?></label>
          <input class="widefat" id="<?php echo $this->get_field_id( 'firsttimevisitorlink' ); ?>" name="<?php echo $this->get_field_name( 'firsttimevisitorlink' ); ?>" type="text" value="<?php echo esc_attr( $firsttimevisitorlink ); ?>" />
        </p>
    <?php
    }
}