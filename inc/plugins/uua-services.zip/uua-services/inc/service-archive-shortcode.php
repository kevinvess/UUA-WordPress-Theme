<?php 
	
	function uuaservices_shortcode_service_archive( $atts ){ 
		
		$sapaged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
	  $sashortcode_args = array( 
	     'post_type' 			=> 'uu_services',
	     'posts_per_page'	=> 20,
	     'paged' 					=> $sapaged
	    );
      $service_archive_shortcode = new WP_Query( $sashortcode_args );
      if ( $service_archive_shortcode->have_posts() ) : ?>
      
      <div class="uu-service-list">
		    <?php $sacount = 0; ?>
				<?php while ($service_archive_shortcode->have_posts()) : $service_archive_shortcode->the_post(); ?>
				<?php $sacount++; ?>
				<?php 
					if ($sacount < 4 && $sapaged == 1) : // Check for the first blog post in the loop && makes sure it the first page of results
				?>
		      <article <?php post_class('service-archive featured'); ?>>
			      <p class="small service-meta"><time datetime="<?php echo get_the_time('c'); ?>"><?php the_time('M j, Y'); ?></time> <span class="speaker"><?php the_terms( '', 'uu_service_speaker', '', ', ' ); ?></span> <span class="speaker"><?php the_terms( '', 'uu_service_topics', '', ', ' ); ?></span></p>
			      <div class="entry-content">
				      <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
				      <?php the_excerpt(); ?>
			      </div>
		      </article>
			
				<?php else : ?>			
			
		      <article <?php post_class('service-archive-list'); ?>>
			      <div class="entry-content small">
			      <time datetime="<?php echo get_the_time('c'); ?>"><?php the_time('M j, Y'); ?></time> 
			      <span class="speaker"><?php the_terms( '', 'uu_service_speaker', '', ', ' ); ?></span>
<!-- 			      <span class="topics"><?php the_terms( '', 'uu_service_topics', '', ', ' ); ?></span> -->
			      <span class="service-title"><a href="<?php the_permalink(); ?>"><strong><?php the_title(); ?></strong></a></span>
			      </div>
		      </article>
								
				<?php endif; ?>
				<?php endwhile; ?>
				
		    <?php $args = [
				  		  				'query' => $service_archive_shortcode
											];
					echo get_paginated_numbers( $args ); 
				?>
      </div>
								
			<?php else : ?>
			
				<!-- Content that will display if no posts are available - Requires a content-none.php or replace with code -->
				<?php get_template_part( 'content', 'none' ); ?>
					    
    <?php endif; ?>
    <?php wp_reset_postdata(); 

  }

add_shortcode( 'service-archive', 'uuaservices_shortcode_service_archive' );