CMB2-Example-Plugin
===================

Demonstrate how to include CMB2 as well as some cool tips and tricks

Please cross-reference the [CMB2 wiki](https://github.com/WebDevStudios/CMB2/wiki), and the provided [example-functions.php](https://github.com/WebDevStudios/CMB2/blob/master/example-functions.php), as this code-base could be out of date.
