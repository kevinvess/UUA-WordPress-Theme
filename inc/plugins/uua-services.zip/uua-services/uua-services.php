<?php
/**
 * Plugin Name: UUA Services Plugin
 * Plugin URI: http://patienceandfortitude.com
 * Description: A plugin to enable a service post type.
 * Version: 0.4
 * Author: Christopher Wulff
 * Author URI: http://patienceandfortitude.com
 * Requires at least: 4.1
 * Tested up to: 4.1
 *
 */

/**
 * Silence is golden; exit if accessed directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load External Files for Services
 */
require_once 'inc/types-taxonomies.php';
require_once 'inc/services-pagination.php';
require_once 'inc/featured-upcoming-service-widget.php';
require_once 'inc/upcoming-services-widget.php';
require_once 'inc/recent-services-widget.php';
require_once 'inc/service-archive-shortcode.php';
require_once 'inc/upcoming-services-shortcode.php';